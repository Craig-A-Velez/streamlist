/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['lh3.googleusercontent.com'], // Add any other external domains as needed
    },
};

export default nextConfig;
